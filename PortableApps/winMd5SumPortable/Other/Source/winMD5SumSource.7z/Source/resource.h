//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by winMd5Sum.rc
//
#define MANIFEST_RESOURCE_ID            2
#define IDD_MAIN                        101
#define IDI_ICON1                       102
#define IDC_MD5SUM                      1000
#define IDC_FILENAME                    1001
#define ID_CALCULATE                    1002
#define IDC_BROWSE                      1003
#define IDC_MD5COMPARE                  1004
#define IDC_COMPARE                     1005
#define IDC_BUTTON1                     1006
#define IDC_ABOUT                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
